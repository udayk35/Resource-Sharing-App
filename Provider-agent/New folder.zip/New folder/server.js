import express, { json } from "express";
import mongoose from "mongoose";
import { config } from "dotenv"
import cors from "cors";
import { listContainers, startContainer, stopContainer, pullImage, createContainer, readFile, attachTerminal, writeFile, listFiles,
    getBatteryStatus,getCPUInfo,getRAMInfo,getNetworkInfo
 } from "./functions.js";

config();
const app = express();
app.use(cors());
app.use(json());

// Connect to MongoDB

// Define API routes
app.get("/containers", listContainers);

// Route to start a container
app.post("/containers/:containerId/start", startContainer);

// Route to stop and remove a container
app.post("/containers/:containerId/stop", stopContainer);

// Route to pull a Docker image
app.post("/images/pull", pullImage);

// Route to create a new container
app.post("/containers/create", createContainer);

// Route to read a file from a container
app.post("/containers/read-file", readFile);

// Route to write a file to a container
app.post("/containers/write-file", writeFile);

// Route to list files in a container directory
app.get("/containers/list-files", listFiles);

app.get("/getraminfo",getRAMInfo);

app.get("/getcpuinfo",getCPUInfo);

app.get("/getbatteryinfo",getBatteryStatus);


// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
