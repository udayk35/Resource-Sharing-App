import Docker from "dockerode";
import tar from "tar-fs";
import si from 'systeminformation';
import { Readable } from "stream";


const docker = new Docker();

async function buildCustomImage(image) {
  return new Promise((resolve, reject) => {
    const dockerfileContent = `
      FROM ${image}
      RUN useradd -m myuser
      RUN echo 'myuser:mypassword' | chpasswd
    `;
    const pack = tar.pack();
    pack.entry({ name: "Dockerfile" }, dockerfileContent);
    pack.finalize();

    docker.buildImage(pack, { t: 'custom-node-with-myuser' }, (err, response) => {
      if (err) return reject(err);

      // Log build output
      response.on('data', (chunk) => console.log(chunk.toString()));
      response.on('end', () => resolve('custom-node-with-myuser'));
      response.on('error', (err) => reject(err));
    });
  });
}

async function listContainers(req, res) {
  try {
    const containers = await docker.listContainers({ all: true });
    return res.json({ containers: containers });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

async function startContainer(req, res) {
  const { containerId } = req.params;
  try {
    const container = docker.getContainer(containerId);
    await container.start();
    res.json({ message: `Container ${containerId} started successfully` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

async function stopContainer(req, res) {
  const { containerId } = req.params;
  console.log(containerId);
  try {
    const container = docker.getContainer(containerId);
    await container.stop();
    await container.remove();
    res.json({ message: `Container ${containerId} stopped successfully` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

async function pullImage(req, res) {
  const { imageName } = req.body;
  try {
    await docker.pull(imageName);
    res.json({ message: `Image ${imageName} pulled successfully` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

async function createContainer(req, res) {
  const { imageName} = req.body;
  console.log(imageName);
  try {
    const image = await buildCustomImage();
    const containerConfig = {
      Image: image,
      Cmd: ["bash", "--login"],
      AttachStdin: true,
      AttachStdout: true,
      AttachStderr: true,
      Tty: true,
      OpenStdin: true,
      HostConfig: {
        AutoRemove: true,
      },
      User: "myuser",
    };

    const container = await docker.createContainer(containerConfig);
    console.log(container);
    await container.start();

    const exec = await container.exec({
      Cmd: [
        "sh",
        "-c",
        `
        echo 'myuser:mypassword' | chpasswd && \
        mkdir -p /myfolder && \
        chown -R myuser:myuser /myfolder && \
        chmod -R 744 /myfolder
        sed -i 's/^auth.*pam_rootok.so$/# &/' /etc/pam.d/su
        `,
      ],
      AttachStdin:true,
      AttachStdout: true,
      AttachStderr: true,
    });

    res.status(201).json({
      message: "Container created successfully.",
      containerId: container.id,
      username: "myuser",
      password: "mypassword",
    });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: error.message });
  }
}

async function readFile(req, res) {
  const { containerId, filePath } = req.body;

  if (!containerId || !filePath) {
    return res
      .status(400)
      .json({ error: "containerId and filePath are required" });
  }

  try {
    const container = docker.getContainer(containerId);
    const exec = await container.exec({
      Cmd: ["cat", filePath],
      AttachStdout: true,
      AttachStderr: true,
    });

    const stream = await exec.start({ hijack: true, stdin: true });
    let fileContent = "";

    stream.on("data", (chunk) => {
      fileContent += chunk.toString();
    });

    stream.on("end", () => {
      res.json({ content: fileContent.toString("base64") });
    });

    stream.on("error", (err) => {
      console.error("Stream error:", err);
      res.status(500).json({ error: "Failed to read file from container" });
    });
  } catch (err) {
    console.error("Error:", err);
    res.status(500).json({ error: err.message });
  }
}

async function attachTerminal(ws, req) {
  const { containerId } = req.params;

  if (!containerId) {
    ws.send(JSON.stringify({ error: "No containerId provided" }));
    return;
  }

  const container = docker.getContainer(containerId);
  console.log(containerId);

  container.inspect(async (err, data) => {
    if (err || !data) {
      ws.send(JSON.stringify({ error: `No such container: ${containerId}` }));
      return;
    }

    const exec = await container.exec({
      Cmd: ["/bin/bash"],
      AttachStdin: true,
      AttachStdout: true,
      AttachStderr: true,
      Tty: true,
      WorkingDir: "/app",
    });

    exec.start({ hijack: true, stdin: true, tty: true }, (err, stream) => {
      if (err) {
        ws.send(JSON.stringify({ error: err.message }));
        return;
      }

      stream.on("data", (chunk) => {
        const output = chunk.toString();
        console.log(output);
        ws.send(output);
      });
      stream.on("error", (err) => console.error(err));
      ws.on("message", (message) => {
        console.log(message);
        stream.write(message + "\r");
      });

      ws.on("close", () => {
        console.log("Client disconnected.");
        stream.end();
      });

      ws.on("error", (error) => {
        console.error("WebSocket Error:", error);
      });
    });
  });
}
const writeFile = async (req, res) => {
  const { containerId, filePath, content } = req.body;
  console.log(content + " " + filePath);
  try {
    const container = docker.getContainer(containerId);
    const exec = await container.exec({
      Cmd: ["sh", "-c", `echo '${content}' > ${filePath}`],
      AttachStdout: true,
      AttachStderr: true,
    });

    const stream = await exec.start({ hijack: true, stdin: true });
    stream.on("data", () => {});
    stream.on("end", () => res.json({ message: "File saved successfully" }));
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: err.message });
  }
};

// List files in a directory
const listFiles = async (req, res) => {
  const { containerId, dirPath } = req.body;
  try {
    const container = docker.getContainer(containerId);
    const exec = await container.exec({
      Cmd: ["ls", dirPath],
      AttachStdout: true,
      AttachStderr: true,
    });

    const stream = await exec.start({ hijack: true, stdin: true });
    let output = "";

    stream.on("data", (chunk) => (output += chunk.toString()));
    stream.on("end", () => {
      res.json({ files: output });
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
export async function getBatteryStatus(req, res) {
  try {
    const batteryInfo = await si.battery();
    res.json({ batteryPercentage: batteryInfo.percent });
  } catch (error) {
    res
      .status(500)
      .json({ message: 'Error retrieving battery info', error: error.message });
  }
}
export async function getRAMInfo(req, res) {
  try {
    const memory = await si.mem();

    res.json({
      totalRAM: memory.total / (1024 * 1024 * 1024), // Convert to GB
      freeRAM: memory.free / (1024 * 1024 * 1024), // Convert to GB
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: 'Error retrieving RAM info', error: error.message });
  }
}
export async function getNetworkInfo(req, res) {
  try {
    const networkStats = await si.networkStats();
    const networkInterfaces = networkStats.map((net) => ({
      iface: net.iface,
      rx_bytes: (net.rx_bytes / (1024 * 1024)).toFixed(2), // Received data in MB
      tx_bytes: (net.tx_bytes / (1024 * 1024)).toFixed(2), // Transmitted data in MB
      rx_sec: (net.rx_sec / (1024 * 1024)).toFixed(2), // Received speed in MB/s
      tx_sec: (net.tx_sec / (1024 * 1024)).toFixed(2), // Transmitted speed in MB/s
    }));

    res.json(networkInterfaces);
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving Network info', error: error.message });
  }
}
export async function getCPUInfo(req, res) {
  try {
    const cpuLoad = await si.currentLoad();
    res.json({
      cpuUsage: cpuLoad.currentLoad.toFixed(2) + '%', // CPU load percentage
    });
  } catch (error) {
    res.status(500).json({ message: 'Error retrieving CPU info', error: error.message });
  }
}

export {
  buildCustomImage,
  listContainers,
  startContainer,
  stopContainer,
  pullImage,
  createContainer,
  readFile,
  attachTerminal,
  writeFile,
  listFiles,
};
